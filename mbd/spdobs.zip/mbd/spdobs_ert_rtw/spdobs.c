/*
 * File: spdobs.c
 *
 * Code generated for Simulink model 'spdobs'.
 *
 * Model version                  : 1.77
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Jan  6 22:00:46 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 *    3. ROM efficiency
 * Validation result: Not run
 */

#include "spdobs.h"
#include "spdobs_private.h"

/* Block states (auto storage) */
DW_spdobs_T spdobs_DW;

/* Real-time model */
RT_MODEL_spdobs_T spdobs_M_;
RT_MODEL_spdobs_T *const spdobs_M = &spdobs_M_;
int32_T MultiWord2sLong(const uint32_T u[])
{
  return (int32_T)u[0];
}

void sMultiWordShr(const uint32_T u1[], int32_T n1, uint32_T n2, uint32_T y[],
                   int32_T n)
{
  int32_T nb;
  int32_T i;
  uint32_T ys;
  uint32_T yi;
  uint32_T u1i;
  int32_T nc;
  uint32_T nr;
  uint32_T nl;
  int32_T i1;
  nb = (int32_T)(n2 >> 5);
  i = 0;
  ys = (u1[n1 - 1] & 2147483648U) != 0U ? MAX_uint32_T : 0U;
  if (nb < n1) {
    nc = n + nb;
    if (nc > n1) {
      nc = n1;
    }

    nr = n2 - ((uint32_T)nb << 5);
    if (nr > 0U) {
      nl = 32U - nr;
      u1i = u1[nb];
      for (i1 = nb + 1; i1 < nc; i1++) {
        yi = u1i >> nr;
        u1i = u1[i1];
        y[i] = u1i << nl | yi;
        i++;
      }

      yi = u1i >> nr;
      u1i = nc < n1 ? u1[nc] : ys;
      y[i] = u1i << nl | yi;
      i++;
    } else {
      for (i1 = nb; i1 < nc; i1++) {
        y[i] = u1[i1];
        i++;
      }
    }
  }

  while (i < n) {
    y[i] = ys;
    i++;
  }
}

void sMultiWordMul(const uint32_T u1[], int32_T n1, const uint32_T u2[], int32_T
                   n2, uint32_T y[], int32_T n)
{
  int32_T i;
  int32_T j;
  int32_T k;
  int32_T nj;
  uint32_T u1i;
  uint32_T yk;
  uint32_T a1;
  uint32_T a0;
  uint32_T b1;
  uint32_T w10;
  uint32_T w01;
  uint32_T cb;
  boolean_T isNegative1;
  boolean_T isNegative2;
  uint32_T cb1;
  uint32_T cb2;
  isNegative1 = ((u1[n1 - 1] & 2147483648U) != 0U);
  isNegative2 = ((u2[n2 - 1] & 2147483648U) != 0U);
  cb1 = 1U;

  /* Initialize output to zero */
  for (k = 0; k < n; k++) {
    y[k] = 0U;
  }

  for (i = 0; i < n1; i++) {
    cb = 0U;
    u1i = u1[i];
    if (isNegative1) {
      u1i = ~u1i + cb1;
      cb1 = (uint32_T)(u1i < cb1);
    }

    a1 = u1i >> 16U;
    a0 = u1i & 65535U;
    cb2 = 1U;
    k = n - i;
    nj = n2 <= k ? n2 : k;
    k = i;
    for (j = 0; j < nj; j++) {
      yk = y[k];
      u1i = u2[j];
      if (isNegative2) {
        u1i = ~u1i + cb2;
        cb2 = (uint32_T)(u1i < cb2);
      }

      b1 = u1i >> 16U;
      u1i &= 65535U;
      w10 = a1 * u1i;
      w01 = a0 * b1;
      yk += cb;
      cb = (uint32_T)(yk < cb);
      u1i *= a0;
      yk += u1i;
      cb += (yk < u1i);
      u1i = w10 << 16U;
      yk += u1i;
      cb += (yk < u1i);
      u1i = w01 << 16U;
      yk += u1i;
      cb += (yk < u1i);
      y[k] = yk;
      cb += w10 >> 16U;
      cb += w01 >> 16U;
      cb += a1 * b1;
      k++;
    }

    if (k < n) {
      y[k] = cb;
    }
  }

  /* Apply sign */
  if (isNegative1 != isNegative2) {
    cb = 1U;
    for (k = 0; k < n; k++) {
      yk = ~y[k] + cb;
      y[k] = yk;
      cb = (uint32_T)(yk < cb);
    }
  }
}

void ssuMultiWordMul(const uint32_T u1[], int32_T n1, const uint32_T u2[],
                     int32_T n2, uint32_T y[], int32_T n)
{
  int32_T i;
  int32_T j;
  int32_T k;
  int32_T nj;
  uint32_T u1i;
  uint32_T yk;
  uint32_T a1;
  uint32_T a0;
  uint32_T b1;
  uint32_T w10;
  uint32_T w01;
  uint32_T cb;
  boolean_T isNegative1;
  uint32_T cb1;
  isNegative1 = ((u1[n1 - 1] & 2147483648U) != 0U);
  cb1 = 1U;

  /* Initialize output to zero */
  for (k = 0; k < n; k++) {
    y[k] = 0U;
  }

  for (i = 0; i < n1; i++) {
    cb = 0U;
    u1i = u1[i];
    if (isNegative1) {
      u1i = ~u1i + cb1;
      cb1 = (uint32_T)(u1i < cb1);
    }

    a1 = u1i >> 16U;
    a0 = u1i & 65535U;
    k = n - i;
    nj = n2 <= k ? n2 : k;
    k = i;
    for (j = 0; j < nj; j++) {
      yk = y[k];
      u1i = u2[j];
      b1 = u1i >> 16U;
      u1i &= 65535U;
      w10 = a1 * u1i;
      w01 = a0 * b1;
      yk += cb;
      cb = (uint32_T)(yk < cb);
      u1i *= a0;
      yk += u1i;
      cb += (yk < u1i);
      u1i = w10 << 16U;
      yk += u1i;
      cb += (yk < u1i);
      u1i = w01 << 16U;
      yk += u1i;
      cb += (yk < u1i);
      y[k] = yk;
      cb += w10 >> 16U;
      cb += w01 >> 16U;
      cb += a1 * b1;
      k++;
    }

    if (k < n) {
      y[k] = cb;
    }
  }

  /* Apply sign */
  if (isNegative1) {
    cb = 1U;
    for (k = 0; k < n; k++) {
      yk = ~y[k] + cb;
      y[k] = yk;
      cb = (uint32_T)(yk < cb);
    }
  }
}

void MultiWordAdd(const uint32_T u1[], const uint32_T u2[], uint32_T y[],
                  int32_T n)
{
  uint32_T yi;
  uint32_T u1i;
  uint32_T carry = 0U;
  int32_T i;
  for (i = 0; i < n; i++) {
    u1i = u1[i];
    yi = (u1i + u2[i]) + carry;
    y[i] = yi;
    carry = carry != 0U ? (uint32_T)(yi <= u1i) : (uint32_T)(yi < u1i);
  }
}

void sMultiWord2MultiWord(const uint32_T u1[], int32_T n1, uint32_T y[], int32_T
  n)
{
  uint32_T u1i;
  int32_T nm;
  int32_T i;
  nm = n1 < n ? n1 : n;
  for (i = 0; i < nm; i++) {
    y[i] = u1[i];
  }

  if (n > n1) {
    u1i = (u1[n1 - 1] & 2147483648U) != 0U ? MAX_uint32_T : 0U;
    for (i = nm; i < n; i++) {
      y[i] = u1i;
    }
  }
}

void sMultiWordShl(const uint32_T u1[], int32_T n1, uint32_T n2, uint32_T y[],
                   int32_T n)
{
  int32_T nb;
  int32_T nc;
  int32_T i;
  uint32_T ys;
  uint32_T u1i;
  uint32_T yi;
  uint32_T nr;
  uint32_T nl;
  nb = (int32_T)(n2 >> 5);
  ys = (u1[n1 - 1] & 2147483648U) != 0U ? MAX_uint32_T : 0U;
  nc = nb > n ? n : nb;
  u1i = 0U;
  for (i = 0; i < nc; i++) {
    y[i] = 0U;
  }

  if (nb < n) {
    nl = n2 - ((uint32_T)nb << 5);
    nb += n1;
    if (nb > n) {
      nb = n;
    }

    nb -= i;
    if (nl > 0U) {
      nr = 32U - nl;
      for (nc = 0; nc < nb; nc++) {
        yi = u1i >> nr;
        u1i = u1[nc];
        y[i] = u1i << nl | yi;
        i++;
      }

      if (i < n) {
        y[i] = u1i >> nr | ys << nl;
        i++;
      }
    } else {
      for (nc = 0; nc < nb; nc++) {
        y[i] = u1[nc];
        i++;
      }
    }
  }

  while (i < n) {
    y[i] = ys;
    i++;
  }
}

void sLong2MultiWord(int32_T u, uint32_T y[], int32_T n)
{
  uint32_T yi;
  int32_T i;
  y[0] = (uint32_T)u;
  yi = u < 0 ? MAX_uint32_T : 0U;
  for (i = 1; i < n; i++) {
    y[i] = yi;
  }
}

boolean_T sMultiWordLe(const uint32_T u1[], const uint32_T u2[], int32_T n)
{
  return sMultiWordCmp(u1, u2, n) <= 0;
}

int32_T sMultiWordCmp(const uint32_T u1[], const uint32_T u2[], int32_T n)
{
  int32_T y;
  uint32_T su1;
  uint32_T su2;
  int32_T i;
  su1 = u1[n - 1] & 2147483648U;
  su2 = u2[n - 1] & 2147483648U;
  if ((su1 ^ su2) != 0U) {
    y = su1 != 0U ? -1 : 1;
  } else {
    y = 0;
    i = n;
    while ((y == 0) && (i > 0)) {
      i--;
      su1 = u1[i];
      su2 = u2[i];
      if (su1 != su2) {
        y = su1 > su2 ? 1 : -1;
      }
    }
  }

  return y;
}

void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                  *ptrOutBitsLo)
{
  uint32_T absIn0;
  uint32_T absIn1;
  uint32_T in0Lo;
  uint32_T in0Hi;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn0 = in0 < 0 ? ~(uint32_T)in0 + 1U : (uint32_T)in0;
  absIn1 = in1 < 0 ? ~(uint32_T)in1 + 1U : (uint32_T)in1;
  in0Hi = absIn0 >> 16U;
  in0Lo = absIn0 & 65535U;
  in1Hi = absIn1 >> 16U;
  absIn0 = absIn1 & 65535U;
  productHiLo = in0Hi * absIn0;
  productLoHi = in0Lo * in1Hi;
  absIn0 *= in0Lo;
  absIn1 = 0U;
  in0Lo = (productLoHi << /*MW:OvBitwiseOk*/ 16U) + /*MW:OvCarryOk*/ absIn0;
  if (in0Lo < absIn0) {
    absIn1 = 1U;
  }

  absIn0 = in0Lo;
  in0Lo += /*MW:OvCarryOk*/ productHiLo << /*MW:OvBitwiseOk*/ 16U;
  if (in0Lo < absIn0) {
    absIn1++;
  }

  absIn0 = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi) +
    absIn1;
  if (!((in0 == 0) || ((in1 == 0) || ((in0 > 0) == (in1 > 0))))) {
    absIn0 = ~absIn0;
    in0Lo = ~in0Lo;
    in0Lo++;
    if (in0Lo == 0U) {
      absIn0++;
    }
  }

  *ptrOutBitsHi = absIn0;
  *ptrOutBitsLo = in0Lo;
}

int32_T mul_s32_loSR(int32_T a, int32_T b, uint32_T aShift)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_s32(a, b, &u32_chi, &u32_clo);
  u32_clo = u32_chi << /*MW:OvBitwiseOk*/ (32U - aShift) | u32_clo >> aShift;
  return (int32_T)u32_clo;
}

void mul_wide_su32(int32_T in0, uint32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                   *ptrOutBitsLo)
{
  uint32_T outBitsLo;
  uint32_T absIn0;
  uint32_T in0Hi;
  uint32_T in1Lo;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn0 = in0 < 0 ? ~(uint32_T)in0 + 1U : (uint32_T)in0;
  in0Hi = absIn0 >> 16U;
  absIn0 &= 65535U;
  in1Hi = in1 >> 16U;
  in1Lo = in1 & 65535U;
  productHiLo = in0Hi * in1Lo;
  productLoHi = absIn0 * in1Hi;
  absIn0 *= in1Lo;
  in1Lo = 0U;
  outBitsLo = (productLoHi << /*MW:OvBitwiseOk*/ 16U) + /*MW:OvCarryOk*/ absIn0;
  if (outBitsLo < absIn0) {
    in1Lo = 1U;
  }

  absIn0 = outBitsLo;
  outBitsLo += /*MW:OvCarryOk*/ productHiLo << /*MW:OvBitwiseOk*/ 16U;
  if (outBitsLo < absIn0) {
    in1Lo++;
  }

  absIn0 = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi) +
    in1Lo;
  if (!((in1 == 0U) || (in0 >= 0))) {
    absIn0 = ~absIn0;
    outBitsLo = ~outBitsLo;
    outBitsLo++;
    if (outBitsLo == 0U) {
      absIn0++;
    }
  }

  *ptrOutBitsHi = absIn0;
  *ptrOutBitsLo = outBitsLo;
}

int32_T mul_ssu32_loSR(int32_T a, uint32_T b, uint32_T aShift)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_su32(a, b, &u32_chi, &u32_clo);
  u32_clo = u32_chi << /*MW:OvBitwiseOk*/ (32U - aShift) | u32_clo >> aShift;
  return (int32_T)u32_clo;
}

void mul_wide_u32(uint32_T in0, uint32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                  *ptrOutBitsLo)
{
  uint32_T outBitsLo;
  uint32_T in0Lo;
  uint32_T in0Hi;
  uint32_T in1Lo;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  in0Hi = in0 >> 16U;
  in0Lo = in0 & 65535U;
  in1Hi = in1 >> 16U;
  in1Lo = in1 & 65535U;
  productHiLo = in0Hi * in1Lo;
  productLoHi = in0Lo * in1Hi;
  in0Lo *= in1Lo;
  in1Lo = 0U;
  outBitsLo = (productLoHi << /*MW:OvBitwiseOk*/ 16U) + /*MW:OvCarryOk*/ in0Lo;
  if (outBitsLo < in0Lo) {
    in1Lo = 1U;
  }

  in0Lo = outBitsLo;
  outBitsLo += /*MW:OvCarryOk*/ productHiLo << /*MW:OvBitwiseOk*/ 16U;
  if (outBitsLo < in0Lo) {
    in1Lo++;
  }

  *ptrOutBitsHi = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi)
    + in1Lo;
  *ptrOutBitsLo = outBitsLo;
}

uint32_T mul_u32_loSR(uint32_T a, uint32_T b, uint32_T aShift)
{
  uint32_T result;
  uint32_T u32_chi;
  mul_wide_u32(a, b, &u32_chi, &result);
  return u32_chi << /*MW:OvBitwiseOk*/ (32U - aShift) | result >> aShift;
}

int32_T rt_sqrt_Us32En5_Ys32En_IpymlhWf(int32_T u)
{
  int32_T y;
  int32_T tmp01_y;
  int32_T shiftMask;
  int64m_T tmp03_u;
  int32_T iBit;
  int64m_T tmp;
  uint32_T tmp_0;
  uint32_T tmp_1;

  /* Fixed-Point Sqrt Computation by the bisection method. */
  if (u > 0) {
    y = 0;
    shiftMask = 1073741824;
    sLong2MultiWord(u, &tmp.chunks[0U], 2);
    sMultiWordShl(&tmp.chunks[0U], 2, 5U, &tmp03_u.chunks[0U], 2);
    for (iBit = 0; iBit < 31; iBit++) {
      tmp01_y = y | shiftMask;
      tmp_0 = (uint32_T)tmp01_y;
      tmp_1 = (uint32_T)tmp01_y;
      sMultiWordMul(&tmp_0, 1, &tmp_1, 1, &tmp.chunks[0U], 2);
      if (sMultiWordLe(&tmp.chunks[0U], &tmp03_u.chunks[0U], 2)) {
        y = tmp01_y;
      }

      shiftMask = (int32_T)((uint32_T)shiftMask >> 1U);
    }
  } else {
    y = 0;
  }

  return y;
}

/* Model step function */
void SpdObs_Step(Degs arg_MotorPos, Degs_s *arg_MtrSpd, Degs_s *arg_MtrSpdFil)
{
  int32_T rtb_Sign;
  Degs_s rtb_UnitDelay_j;
  Degs_s rtb_Add1;
  int32_T tmp;
  int128m_T tmp_0;
  int128m_T tmp_1;
  int64m_T tmp_2;
  int64m_T tmp_3;
  int96m_T tmp_4;
  int96m_T tmp_5;
  uint32_T tmp_6;
  int128m_T tmp_7;
  uint32_T tmp_8;
  int64m_T tmp_9;
  static int64m_T tmp_a = { { 2696277389U, 1099511U }/* chunks */
  };

  static int64m_T tmp_b = { { 1U, 1310720U }/* chunks */
  };

  static int64m_T tmp_c = { { 1U, 1638400U }/* chunks */
  };

  /* DataTypeConversion: '<S3>/Data Type Conversion3' incorporates:
   *  UnitDelay: '<S5>/Unit Delay'
   */
  tmp_2 = spdobs_DW.UnitDelay_DSTATE;
  tmp_3 = tmp_a;
  sMultiWordMul(&tmp_2.chunks[0U], 2, &tmp_3.chunks[0U], 2, &tmp_1.chunks[0U], 4);
  sMultiWordShr(&tmp_1.chunks[0U], 4, 72U, &tmp_0.chunks[0U], 4);

  /* Sum: '<S3>/Add' incorporates:
   *  DataTypeConversion: '<S3>/Data Type Conversion3'
   *  Inport: '<Root>/MotorPos'
   */
  rtb_Sign = arg_MotorPos - MultiWord2sLong(&tmp_0.chunks[0U]);

  /* Abs: '<S3>/Abs' */
  if (rtb_Sign < 0) {
    rtb_UnitDelay_j = (int32_T)mul_u32_loSR((uint32_T)-rtb_Sign, 3435973837U,
      30U);
  } else {
    rtb_UnitDelay_j = (int32_T)mul_u32_loSR((uint32_T)rtb_Sign, 3435973837U, 30U);
  }

  /* Signum: '<S3>/Sign' */
  if (rtb_Sign < 0) {
    rtb_Sign = -1;
  } else {
    rtb_Sign = (rtb_Sign > 0);
  }

  /* End of Signum: '<S3>/Sign' */

  /* Gain: '<S3>/Gain2' incorporates:
   *  UnitDelay: '<S4>/Unit Delay'
   */
  tmp_2 = spdobs_DW.UnitDelay_DSTATE_i;
  tmp_6 = 1575625U;
  ssuMultiWordMul(&tmp_2.chunks[0U], 2, &tmp_6, 1, &tmp_5.chunks[0U], 3);
  sMultiWordShr(&tmp_5.chunks[0U], 3, 22U, &tmp_4.chunks[0U], 3);

  /* Sum: '<S3>/Add1' incorporates:
   *  Abs: '<S3>/Abs'
   *  Gain: '<S3>/Gain1'
   *  Gain: '<S3>/Gain2'
   *  Product: '<S3>/Product'
   *  Sqrt: '<S3>/Sqrt'
   */
  rtb_UnitDelay_j = mul_ssu32_loSR(rt_sqrt_Us32En5_Ys32En_IpymlhWf
    (rtb_UnitDelay_j) * rtb_Sign, 7569U, 5U) + mul_s32_loSR(MultiWord2sLong
    (&tmp_4.chunks[0U]), 1801439851, 30U);

  /* Outport: '<Root>/MtrSpd' */
  *arg_MtrSpd = rtb_UnitDelay_j;

  /* Gain: '<S2>/Gain' */
  rtb_Add1 = (int32_T)fmod((int32_T)floor((real_T)rtb_UnitDelay_j * 0.1 *
    0.038461538461538464 / 0.1), 4.294967296E+9);

  /* Gain: '<S2>/Gain1' incorporates:
   *  UnitDelay: '<S2>/Unit Delay'
   */
  tmp = (int32_T)fmod((int32_T)floor((real_T)spdobs_DW.UnitDelay_DSTATE_f * 0.1 *
    0.96153846153846156 / 0.1), 4.294967296E+9);

  /* Sum: '<S2>/Add1' incorporates:
   *  Gain: '<S2>/Gain'
   *  Gain: '<S2>/Gain1'
   */
  rtb_Add1 = (rtb_Add1 < 0 ? -(int32_T)(uint32_T)-(real_T)rtb_Add1 : rtb_Add1) +
    (tmp < 0 ? -(int32_T)(uint32_T)-(real_T)tmp : tmp);

  /* Outport: '<Root>/MtrSpdFil' */
  *arg_MtrSpdFil = rtb_Add1;

  /* Gain: '<S5>/Gain' */
  tmp_6 = 10U;
  tmp_8 = (uint32_T)rtb_UnitDelay_j;
  sMultiWordMul(&tmp_6, 1, &tmp_8, 1, &tmp_3.chunks[0U], 2);
  tmp_9 = tmp_b;
  sMultiWordMul(&tmp_3.chunks[0U], 2, &tmp_9.chunks[0U], 2, &tmp_7.chunks[0U], 4);
  sMultiWordShr(&tmp_7.chunks[0U], 4, 49U, &tmp_1.chunks[0U], 4);
  sMultiWord2MultiWord(&tmp_1.chunks[0U], 4, &tmp_2.chunks[0U], 2);

  /* Sum: '<S5>/Add2' incorporates:
   *  UnitDelay: '<S5>/Unit Delay'
   */
  tmp_3 = spdobs_DW.UnitDelay_DSTATE;
  MultiWordAdd(&tmp_2.chunks[0U], &tmp_3.chunks[0U], &tmp_9.chunks[0U], 2);

  /* Update for UnitDelay: '<S5>/Unit Delay' incorporates:
   *  Gain: '<S5>/Gain'
   *  Sum: '<S5>/Add2'
   */
  spdobs_DW.UnitDelay_DSTATE = tmp_9;

  /* Gain: '<S4>/Gain' */
  tmp_8 = (uint32_T)rtb_Sign;
  sMultiWordMul(&tmp_6, 1, &tmp_8, 1, &tmp_3.chunks[0U], 2);
  tmp_9 = tmp_c;
  sMultiWordMul(&tmp_3.chunks[0U], 2, &tmp_9.chunks[0U], 2, &tmp_7.chunks[0U], 4);
  sMultiWordShr(&tmp_7.chunks[0U], 4, 46U, &tmp_1.chunks[0U], 4);
  sMultiWord2MultiWord(&tmp_1.chunks[0U], 4, &tmp_2.chunks[0U], 2);

  /* Sum: '<S4>/Add2' incorporates:
   *  UnitDelay: '<S4>/Unit Delay'
   */
  tmp_3 = spdobs_DW.UnitDelay_DSTATE_i;
  MultiWordAdd(&tmp_2.chunks[0U], &tmp_3.chunks[0U], &tmp_9.chunks[0U], 2);

  /* Update for UnitDelay: '<S4>/Unit Delay' incorporates:
   *  Gain: '<S4>/Gain'
   *  Sum: '<S4>/Add2'
   */
  spdobs_DW.UnitDelay_DSTATE_i = tmp_9;

  /* Update for UnitDelay: '<S2>/Unit Delay' */
  spdobs_DW.UnitDelay_DSTATE_f = rtb_Add1;
}

/* Model initialize function */
void SpdObs_Init(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(spdobs_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&spdobs_DW, 0,
                sizeof(DW_spdobs_T));
}

/* Model terminate function */
void spdobs_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
