function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/MotorPos */
	this.urlHashMap["spdobs:12"] = "spdobs.c:602";
	/* <Root>/MtrSpd */
	this.urlHashMap["spdobs:13"] = "spdobs.c:642";
	/* <Root>/MtrSpdFil */
	this.urlHashMap["spdobs:49"] = "spdobs.c:662";
	/* <S2>/Add1 */
	this.urlHashMap["spdobs:47:3"] = "spdobs.c:655";
	/* <S2>/Data Type
Duplicate */
	this.urlHashMap["spdobs:47:42"] = "msg=rtwMsg_reducedBlock&block=spdobs:47:42";
	/* <S2>/Gain */
	this.urlHashMap["spdobs:47:4"] = "spdobs.c:645,656";
	/* <S2>/Gain1 */
	this.urlHashMap["spdobs:47:5"] = "spdobs.c:649,657";
	/* <S2>/Unit Delay */
	this.urlHashMap["spdobs:47:6"] = "spdobs.c:650,706&spdobs.h:47";
	/* <S3>/Abs */
	this.urlHashMap["spdobs:50:16"] = "spdobs.c:606,632";
	/* <S3>/Add */
	this.urlHashMap["spdobs:50:17"] = "spdobs.c:600";
	/* <S3>/Add1 */
	this.urlHashMap["spdobs:50:18"] = "spdobs.c:631";
	/* <S3>/Data Type
Duplicate */
	this.urlHashMap["spdobs:50:19"] = "msg=rtwMsg_reducedBlock&block=spdobs:50:19";
	/* <S3>/Data Type Conversion3 */
	this.urlHashMap["spdobs:50:20"] = "spdobs.c:592,601";
	/* <S3>/Gain1 */
	this.urlHashMap["spdobs:50:21"] = "spdobs.c:633";
	/* <S3>/Gain2 */
	this.urlHashMap["spdobs:50:22"] = "spdobs.c:623,634";
	/* <S3>/Product */
	this.urlHashMap["spdobs:50:25"] = "spdobs.c:635";
	/* <S3>/Sign */
	this.urlHashMap["spdobs:50:26"] = "spdobs.c:614,621";
	/* <S3>/Sqrt */
	this.urlHashMap["spdobs:50:27"] = "spdobs.c:636";
	/* <S4>/Add2 */
	this.urlHashMap["spdobs:50:23:10"] = "spdobs.c:694,702";
	/* <S4>/Gain */
	this.urlHashMap["spdobs:50:23:11"] = "spdobs.c:686,701";
	/* <S4>/Unit Delay */
	this.urlHashMap["spdobs:50:23:12"] = "spdobs.c:624,695,700&spdobs.h:46";
	/* <S5>/Add2 */
	this.urlHashMap["spdobs:50:24:10"] = "spdobs.c:674,682";
	/* <S5>/Gain */
	this.urlHashMap["spdobs:50:24:11"] = "spdobs.c:665,681";
	/* <S5>/Unit Delay */
	this.urlHashMap["spdobs:50:24:12"] = "spdobs.c:593,675,680&spdobs.h:45";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "spdobs"};
	this.sidHashMap["spdobs"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "spdobs:1"};
	this.sidHashMap["spdobs:1"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "spdobs:47"};
	this.sidHashMap["spdobs:47"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "spdobs:50"};
	this.sidHashMap["spdobs:50"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "spdobs:50:23"};
	this.sidHashMap["spdobs:50:23"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "spdobs:50:24"};
	this.sidHashMap["spdobs:50:24"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<Root>/MotorPos"] = {sid: "spdobs:12"};
	this.sidHashMap["spdobs:12"] = {rtwname: "<Root>/MotorPos"};
	this.rtwnameHashMap["<Root>/SpeedObserver"] = {sid: "spdobs:1"};
	this.sidHashMap["spdobs:1"] = {rtwname: "<Root>/SpeedObserver"};
	this.rtwnameHashMap["<Root>/MtrSpd"] = {sid: "spdobs:13"};
	this.sidHashMap["spdobs:13"] = {rtwname: "<Root>/MtrSpd"};
	this.rtwnameHashMap["<Root>/MtrSpdFil"] = {sid: "spdobs:49"};
	this.sidHashMap["spdobs:49"] = {rtwname: "<Root>/MtrSpdFil"};
	this.rtwnameHashMap["<S1>/MtrPos"] = {sid: "spdobs:2"};
	this.sidHashMap["spdobs:2"] = {rtwname: "<S1>/MtrPos"};
	this.rtwnameHashMap["<S1>/D-1LPF"] = {sid: "spdobs:47"};
	this.sidHashMap["spdobs:47"] = {rtwname: "<S1>/D-1LPF"};
	this.rtwnameHashMap["<S1>/SM-Differentiator"] = {sid: "spdobs:50"};
	this.sidHashMap["spdobs:50"] = {rtwname: "<S1>/SM-Differentiator"};
	this.rtwnameHashMap["<S1>/SpdEst"] = {sid: "spdobs:48"};
	this.sidHashMap["spdobs:48"] = {rtwname: "<S1>/SpdEst"};
	this.rtwnameHashMap["<S1>/SpdEstFil"] = {sid: "spdobs:11"};
	this.sidHashMap["spdobs:11"] = {rtwname: "<S1>/SpdEstFil"};
	this.rtwnameHashMap["<S2>/FiltIn"] = {sid: "spdobs:47:2"};
	this.sidHashMap["spdobs:47:2"] = {rtwname: "<S2>/FiltIn"};
	this.rtwnameHashMap["<S2>/Add1"] = {sid: "spdobs:47:3"};
	this.sidHashMap["spdobs:47:3"] = {rtwname: "<S2>/Add1"};
	this.rtwnameHashMap["<S2>/Data Type Duplicate"] = {sid: "spdobs:47:42"};
	this.sidHashMap["spdobs:47:42"] = {rtwname: "<S2>/Data Type Duplicate"};
	this.rtwnameHashMap["<S2>/Gain"] = {sid: "spdobs:47:4"};
	this.sidHashMap["spdobs:47:4"] = {rtwname: "<S2>/Gain"};
	this.rtwnameHashMap["<S2>/Gain1"] = {sid: "spdobs:47:5"};
	this.sidHashMap["spdobs:47:5"] = {rtwname: "<S2>/Gain1"};
	this.rtwnameHashMap["<S2>/Unit Delay"] = {sid: "spdobs:47:6"};
	this.sidHashMap["spdobs:47:6"] = {rtwname: "<S2>/Unit Delay"};
	this.rtwnameHashMap["<S2>/FiltOut"] = {sid: "spdobs:47:7"};
	this.sidHashMap["spdobs:47:7"] = {rtwname: "<S2>/FiltOut"};
	this.rtwnameHashMap["<S3>/DiffIn"] = {sid: "spdobs:50:15"};
	this.sidHashMap["spdobs:50:15"] = {rtwname: "<S3>/DiffIn"};
	this.rtwnameHashMap["<S3>/Abs"] = {sid: "spdobs:50:16"};
	this.sidHashMap["spdobs:50:16"] = {rtwname: "<S3>/Abs"};
	this.rtwnameHashMap["<S3>/Add"] = {sid: "spdobs:50:17"};
	this.sidHashMap["spdobs:50:17"] = {rtwname: "<S3>/Add"};
	this.rtwnameHashMap["<S3>/Add1"] = {sid: "spdobs:50:18"};
	this.sidHashMap["spdobs:50:18"] = {rtwname: "<S3>/Add1"};
	this.rtwnameHashMap["<S3>/Data Type Duplicate"] = {sid: "spdobs:50:19"};
	this.sidHashMap["spdobs:50:19"] = {rtwname: "<S3>/Data Type Duplicate"};
	this.rtwnameHashMap["<S3>/Data Type Conversion3"] = {sid: "spdobs:50:20"};
	this.sidHashMap["spdobs:50:20"] = {rtwname: "<S3>/Data Type Conversion3"};
	this.rtwnameHashMap["<S3>/Gain1"] = {sid: "spdobs:50:21"};
	this.sidHashMap["spdobs:50:21"] = {rtwname: "<S3>/Gain1"};
	this.rtwnameHashMap["<S3>/Gain2"] = {sid: "spdobs:50:22"};
	this.sidHashMap["spdobs:50:22"] = {rtwname: "<S3>/Gain2"};
	this.rtwnameHashMap["<S3>/Integrator"] = {sid: "spdobs:50:23"};
	this.sidHashMap["spdobs:50:23"] = {rtwname: "<S3>/Integrator"};
	this.rtwnameHashMap["<S3>/Integrator1"] = {sid: "spdobs:50:24"};
	this.sidHashMap["spdobs:50:24"] = {rtwname: "<S3>/Integrator1"};
	this.rtwnameHashMap["<S3>/Product"] = {sid: "spdobs:50:25"};
	this.sidHashMap["spdobs:50:25"] = {rtwname: "<S3>/Product"};
	this.rtwnameHashMap["<S3>/Sign"] = {sid: "spdobs:50:26"};
	this.sidHashMap["spdobs:50:26"] = {rtwname: "<S3>/Sign"};
	this.rtwnameHashMap["<S3>/Sqrt"] = {sid: "spdobs:50:27"};
	this.sidHashMap["spdobs:50:27"] = {rtwname: "<S3>/Sqrt"};
	this.rtwnameHashMap["<S3>/DiffOut"] = {sid: "spdobs:50:28"};
	this.sidHashMap["spdobs:50:28"] = {rtwname: "<S3>/DiffOut"};
	this.rtwnameHashMap["<S4>/IntIn"] = {sid: "spdobs:50:23:9"};
	this.sidHashMap["spdobs:50:23:9"] = {rtwname: "<S4>/IntIn"};
	this.rtwnameHashMap["<S4>/Add2"] = {sid: "spdobs:50:23:10"};
	this.sidHashMap["spdobs:50:23:10"] = {rtwname: "<S4>/Add2"};
	this.rtwnameHashMap["<S4>/Gain"] = {sid: "spdobs:50:23:11"};
	this.sidHashMap["spdobs:50:23:11"] = {rtwname: "<S4>/Gain"};
	this.rtwnameHashMap["<S4>/Unit Delay"] = {sid: "spdobs:50:23:12"};
	this.sidHashMap["spdobs:50:23:12"] = {rtwname: "<S4>/Unit Delay"};
	this.rtwnameHashMap["<S4>/IntOut"] = {sid: "spdobs:50:23:13"};
	this.sidHashMap["spdobs:50:23:13"] = {rtwname: "<S4>/IntOut"};
	this.rtwnameHashMap["<S5>/IntIn"] = {sid: "spdobs:50:24:9"};
	this.sidHashMap["spdobs:50:24:9"] = {rtwname: "<S5>/IntIn"};
	this.rtwnameHashMap["<S5>/Add2"] = {sid: "spdobs:50:24:10"};
	this.sidHashMap["spdobs:50:24:10"] = {rtwname: "<S5>/Add2"};
	this.rtwnameHashMap["<S5>/Gain"] = {sid: "spdobs:50:24:11"};
	this.sidHashMap["spdobs:50:24:11"] = {rtwname: "<S5>/Gain"};
	this.rtwnameHashMap["<S5>/Unit Delay"] = {sid: "spdobs:50:24:12"};
	this.sidHashMap["spdobs:50:24:12"] = {rtwname: "<S5>/Unit Delay"};
	this.rtwnameHashMap["<S5>/IntOut"] = {sid: "spdobs:50:24:13"};
	this.sidHashMap["spdobs:50:24:13"] = {rtwname: "<S5>/IntOut"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
