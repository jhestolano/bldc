function CodeDefine() { 
this.def = new Array();
this.def["spdobs_DW"] = {file: "spdobs_c.html",line:23,type:"var"};
this.def["spdobs_M_"] = {file: "spdobs_c.html",line:26,type:"var"};
this.def["spdobs_M"] = {file: "spdobs_c.html",line:27,type:"var"};
this.def["MultiWord2sLong"] = {file: "spdobs_c.html",line:28,type:"fcn"};
this.def["sMultiWordShr"] = {file: "spdobs_c.html",line:33,type:"fcn"};
this.def["sMultiWordMul"] = {file: "spdobs_c.html",line:83,type:"fcn"};
this.def["ssuMultiWordMul"] = {file: "spdobs_c.html",line:171,type:"fcn"};
this.def["MultiWordAdd"] = {file: "spdobs_c.html",line:250,type:"fcn"};
this.def["sMultiWord2MultiWord"] = {file: "spdobs_c.html",line:265,type:"fcn"};
this.def["sMultiWordShl"] = {file: "spdobs_c.html",line:284,type:"fcn"};
this.def["sLong2MultiWord"] = {file: "spdobs_c.html",line:338,type:"fcn"};
this.def["sMultiWordLe"] = {file: "spdobs_c.html",line:349,type:"fcn"};
this.def["sMultiWordCmp"] = {file: "spdobs_c.html",line:354,type:"fcn"};
this.def["mul_wide_s32"] = {file: "spdobs_c.html",line:380,type:"fcn"};
this.def["mul_s32_loSR"] = {file: "spdobs_c.html",line:426,type:"fcn"};
this.def["mul_wide_su32"] = {file: "spdobs_c.html",line:435,type:"fcn"};
this.def["mul_ssu32_loSR"] = {file: "spdobs_c.html",line:480,type:"fcn"};
this.def["mul_wide_u32"] = {file: "spdobs_c.html",line:489,type:"fcn"};
this.def["mul_u32_loSR"] = {file: "spdobs_c.html",line:523,type:"fcn"};
this.def["rt_sqrt_Us32En5_Ys32En_IpymlhWf"] = {file: "spdobs_c.html",line:531,type:"fcn"};
this.def["SpdObs_Step"] = {file: "spdobs_c.html",line:567,type:"fcn"};
this.def["SpdObs_Init"] = {file: "spdobs_c.html",line:711,type:"fcn"};
this.def["spdobs_terminate"] = {file: "spdobs_c.html",line:724,type:"fcn"};
this.def["DW_spdobs_T"] = {file: "spdobs_h.html",line:48,type:"type"};
this.def["Degs"] = {file: "spdobs_types_h.html",line:26,type:"type"};
this.def["cDegs"] = {file: "spdobs_types_h.html",line:27,type:"type"};
this.def["Degs_s"] = {file: "spdobs_types_h.html",line:34,type:"type"};
this.def["cDegs_s"] = {file: "spdobs_types_h.html",line:35,type:"type"};
this.def["RT_MODEL_spdobs_T"] = {file: "spdobs_types_h.html",line:40,type:"type"};
this.def["long_T"] = {file: "multiword_types_h.html",line:26,type:"type"};
this.def["int64m_T"] = {file: "multiword_types_h.html",line:33,type:"type"};
this.def["cint64m_T"] = {file: "multiword_types_h.html",line:38,type:"type"};
this.def["uint64m_T"] = {file: "multiword_types_h.html",line:42,type:"type"};
this.def["cuint64m_T"] = {file: "multiword_types_h.html",line:47,type:"type"};
this.def["int96m_T"] = {file: "multiword_types_h.html",line:51,type:"type"};
this.def["cint96m_T"] = {file: "multiword_types_h.html",line:56,type:"type"};
this.def["uint96m_T"] = {file: "multiword_types_h.html",line:60,type:"type"};
this.def["cuint96m_T"] = {file: "multiword_types_h.html",line:65,type:"type"};
this.def["int128m_T"] = {file: "multiword_types_h.html",line:69,type:"type"};
this.def["cint128m_T"] = {file: "multiword_types_h.html",line:74,type:"type"};
this.def["uint128m_T"] = {file: "multiword_types_h.html",line:78,type:"type"};
this.def["cuint128m_T"] = {file: "multiword_types_h.html",line:83,type:"type"};
this.def["int160m_T"] = {file: "multiword_types_h.html",line:87,type:"type"};
this.def["cint160m_T"] = {file: "multiword_types_h.html",line:92,type:"type"};
this.def["uint160m_T"] = {file: "multiword_types_h.html",line:96,type:"type"};
this.def["cuint160m_T"] = {file: "multiword_types_h.html",line:101,type:"type"};
this.def["int192m_T"] = {file: "multiword_types_h.html",line:105,type:"type"};
this.def["cint192m_T"] = {file: "multiword_types_h.html",line:110,type:"type"};
this.def["uint192m_T"] = {file: "multiword_types_h.html",line:114,type:"type"};
this.def["cuint192m_T"] = {file: "multiword_types_h.html",line:119,type:"type"};
this.def["int224m_T"] = {file: "multiword_types_h.html",line:123,type:"type"};
this.def["cint224m_T"] = {file: "multiword_types_h.html",line:128,type:"type"};
this.def["uint224m_T"] = {file: "multiword_types_h.html",line:132,type:"type"};
this.def["cuint224m_T"] = {file: "multiword_types_h.html",line:137,type:"type"};
this.def["int256m_T"] = {file: "multiword_types_h.html",line:141,type:"type"};
this.def["cint256m_T"] = {file: "multiword_types_h.html",line:146,type:"type"};
this.def["uint256m_T"] = {file: "multiword_types_h.html",line:150,type:"type"};
this.def["cuint256m_T"] = {file: "multiword_types_h.html",line:155,type:"type"};
this.def["int8_T"] = {file: "rtwtypes_h.html",line:50,type:"type"};
this.def["uint8_T"] = {file: "rtwtypes_h.html",line:51,type:"type"};
this.def["int16_T"] = {file: "rtwtypes_h.html",line:52,type:"type"};
this.def["uint16_T"] = {file: "rtwtypes_h.html",line:53,type:"type"};
this.def["int32_T"] = {file: "rtwtypes_h.html",line:54,type:"type"};
this.def["uint32_T"] = {file: "rtwtypes_h.html",line:55,type:"type"};
this.def["real32_T"] = {file: "rtwtypes_h.html",line:56,type:"type"};
this.def["real64_T"] = {file: "rtwtypes_h.html",line:57,type:"type"};
this.def["real_T"] = {file: "rtwtypes_h.html",line:63,type:"type"};
this.def["time_T"] = {file: "rtwtypes_h.html",line:64,type:"type"};
this.def["boolean_T"] = {file: "rtwtypes_h.html",line:65,type:"type"};
this.def["int_T"] = {file: "rtwtypes_h.html",line:66,type:"type"};
this.def["uint_T"] = {file: "rtwtypes_h.html",line:67,type:"type"};
this.def["ulong_T"] = {file: "rtwtypes_h.html",line:68,type:"type"};
this.def["char_T"] = {file: "rtwtypes_h.html",line:69,type:"type"};
this.def["uchar_T"] = {file: "rtwtypes_h.html",line:70,type:"type"};
this.def["byte_T"] = {file: "rtwtypes_h.html",line:71,type:"type"};
this.def["creal32_T"] = {file: "rtwtypes_h.html",line:81,type:"type"};
this.def["creal64_T"] = {file: "rtwtypes_h.html",line:86,type:"type"};
this.def["creal_T"] = {file: "rtwtypes_h.html",line:91,type:"type"};
this.def["cint8_T"] = {file: "rtwtypes_h.html",line:98,type:"type"};
this.def["cuint8_T"] = {file: "rtwtypes_h.html",line:105,type:"type"};
this.def["cint16_T"] = {file: "rtwtypes_h.html",line:112,type:"type"};
this.def["cuint16_T"] = {file: "rtwtypes_h.html",line:119,type:"type"};
this.def["cint32_T"] = {file: "rtwtypes_h.html",line:126,type:"type"};
this.def["cuint32_T"] = {file: "rtwtypes_h.html",line:133,type:"type"};
this.def["pointer_T"] = {file: "rtwtypes_h.html",line:151,type:"type"};
}
CodeDefine.instance = new CodeDefine();
var testHarnessInfo = {OwnerFileName: "", HarnessOwner: "", HarnessName: "", IsTestHarness: "0"};
var relPathToBuildDir = "../ert_main.c";
var fileSep = "/";
var isPC = false;
function Html2SrcLink() {
	this.html2SrcPath = new Array;
	this.html2Root = new Array;
	this.html2SrcPath["spdobs_c.html"] = "../spdobs.c";
	this.html2Root["spdobs_c.html"] = "spdobs_c.html";
	this.html2SrcPath["spdobs_h.html"] = "../spdobs.h";
	this.html2Root["spdobs_h.html"] = "spdobs_h.html";
	this.html2SrcPath["spdobs_private_h.html"] = "../spdobs_private.h";
	this.html2Root["spdobs_private_h.html"] = "spdobs_private_h.html";
	this.html2SrcPath["spdobs_types_h.html"] = "../spdobs_types.h";
	this.html2Root["spdobs_types_h.html"] = "spdobs_types_h.html";
	this.html2SrcPath["multiword_types_h.html"] = "../multiword_types.h";
	this.html2Root["multiword_types_h.html"] = "multiword_types_h.html";
	this.html2SrcPath["rtwtypes_h.html"] = "../rtwtypes.h";
	this.html2Root["rtwtypes_h.html"] = "rtwtypes_h.html";
	this.html2SrcPath["rtmodel_h.html"] = "../rtmodel.h";
	this.html2Root["rtmodel_h.html"] = "rtmodel_h.html";
	this.getLink2Src = function (htmlFileName) {
		 if (this.html2SrcPath[htmlFileName])
			 return this.html2SrcPath[htmlFileName];
		 else
			 return null;
	}
	this.getLinkFromRoot = function (htmlFileName) {
		 if (this.html2Root[htmlFileName])
			 return this.html2Root[htmlFileName];
		 else
			 return null;
	}
}
Html2SrcLink.instance = new Html2SrcLink();
var fileList = [
"spdobs_c.html","spdobs_h.html","spdobs_private_h.html","spdobs_types_h.html","multiword_types_h.html","rtwtypes_h.html","rtmodel_h.html"];
