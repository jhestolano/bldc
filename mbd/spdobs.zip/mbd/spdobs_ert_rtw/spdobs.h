/*
 * File: spdobs.h
 *
 * Code generated for Simulink model 'spdobs'.
 *
 * Model version                  : 1.77
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Jan  6 22:00:46 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 *    3. ROM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_spdobs_h_
#define RTW_HEADER_spdobs_h_
#include <math.h>
#include <stddef.h>
#include <string.h>
#ifndef spdobs_COMMON_INCLUDES_
# define spdobs_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* spdobs_COMMON_INCLUDES_ */

#include "spdobs_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  int64m_T UnitDelay_DSTATE;           /* '<S5>/Unit Delay' */
  int64m_T UnitDelay_DSTATE_i;         /* '<S4>/Unit Delay' */
  Degs_s UnitDelay_DSTATE_f;           /* '<S2>/Unit Delay' */
} DW_spdobs_T;

/* Real-time Model Data Structure */
struct tag_RTM_spdobs_T {
  const char_T *errorStatus;
};

/* Block states (auto storage) */
extern DW_spdobs_T spdobs_DW;

/* Model entry point functions */
extern void SpdObs_Init(void);
extern void spdobs_terminate(void);

/* Customized model step function */
extern void SpdObs_Step(Degs arg_MotorPos, Degs_s *arg_MtrSpd, Degs_s
  *arg_MtrSpdFil);

/* Real-time Model object */
extern RT_MODEL_spdobs_T *const spdobs_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S2>/Data Type Duplicate' : Unused code path elimination
 * Block '<S3>/Data Type Duplicate' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'spdobs'
 * '<S1>'   : 'spdobs/SpeedObserver'
 * '<S2>'   : 'spdobs/SpeedObserver/D-1LPF'
 * '<S3>'   : 'spdobs/SpeedObserver/SM-Differentiator'
 * '<S4>'   : 'spdobs/SpeedObserver/SM-Differentiator/Integrator'
 * '<S5>'   : 'spdobs/SpeedObserver/SM-Differentiator/Integrator1'
 */
#endif                                 /* RTW_HEADER_spdobs_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
