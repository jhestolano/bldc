/*
 * File: spdobs_types.h
 *
 * Code generated for Simulink model 'spdobs'.
 *
 * Model version                  : 1.77
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Jan  6 22:00:46 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 *    3. ROM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_spdobs_types_h_
#define RTW_HEADER_spdobs_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_Degs_
#define DEFINED_TYPEDEF_FOR_Degs_

typedef int32_T Degs;
typedef cint32_T cDegs;

#endif

#ifndef DEFINED_TYPEDEF_FOR_Degs_s_
#define DEFINED_TYPEDEF_FOR_Degs_s_

typedef int32_T Degs_s;
typedef cint32_T cDegs_s;

#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_spdobs_T RT_MODEL_spdobs_T;

#endif                                 /* RTW_HEADER_spdobs_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
